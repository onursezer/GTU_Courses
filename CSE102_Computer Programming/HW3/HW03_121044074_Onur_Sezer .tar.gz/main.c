/*############################################################################*/
/*HW03_Onur_Sezer_121044074                                                   */
/*______________________                                                      */
/*Written by Onur Sezer on October 8, 2014                                    */
/*                                                                            */
/*Description:                                                                */
/*____________                                                                */
/*Program kullanicidan alinan sutun ve satir sayisi ile pencere cizer,        */
/*ve alinan integer degeri tam ortasina basar.                                */
/*Inputs:                                                                     */
/*int row_count,column_count,n                                                */
/*                                                                            */
/*Outputs:                                                                    */
/*Konsola pencere cizer                                                       */
/*############################################################################*/

/*----------------------------------------------------------------------------*/
/*                             Includes                                       */
/*----------------------------------------------------------------------------*/
#include<stdio.h>
/*----------------------------------------------------------------------------*/
/*                           Function Prototypes                              */
/*----------------------------------------------------------------------------*/
/*###############################################*/
/*Fonksiyon alinan degerler ile pencere cizer    */
/*input: int row_count,column_count,n            */
/*output:Konsola pencere cizer                   */
/*###############################################*/ 
void print_window(int row_count,int column_count,int n);
/*#####################################################*/
/*Fonksiyon integer bir degerin basamak sayisini bulur */
/*input: int n                                         */
/*output:Sonucu return yapar                           */
/*#####################################################*/ 
int basamak(int n);

int main() {
    /*START_OF_MAIN*/
    int row_count,column_count,n;
    /*END_OF_VARIABLES*/
    
    do
    {
        printf("Enter row_count, column_count and n\n");
        scanf("%d%d%d",&row_count,&column_count,&n);
    }
    while( !((row_count>=10 && row_count<=40) && (column_count>=10 && column_count<=40)) );
    

    print_window(row_count,column_count, n);
      
    /*END_OF_MAIN*/
    return 0;
}
void print_window(int row_count,int column_count,int n)
{
    int i,j;
    int num;
    double r1,r2; /*Satirin ortasinin bulunmasinda kullanildi*/
    double c1,c2; /*n sayisini sutunda ortalama isleminde kullanildi*/
    
    r1=row_count/2;
    r2=row_count/2.0;
    
    if(r2>r1){
        r1=row_count/2;
        r2=row_count/2;
    }    
    else{
        r1=row_count/2-1;
        r2=row_count/2;
    }
    
    num=basamak(n);
    c1=(column_count-num)/2;
    c2=(column_count-num)/2.0;
    
    if(c2>c1){
        c1=(column_count-num)/2;
        c2=(column_count-num)/2+1;
    }
    else{
        c1=(column_count-num)/2;
        c2=(column_count-num)/2;
    }
    
    
    for(i=0;i<column_count;++i)
        printf("*");
    printf("\n");   
    
    for(i=1;i<r1;++i){
        printf("*");
        for(j=2;j<column_count;++j)
            printf(" ");
        printf("*\n");    
    }
    
    printf("*");
    for(j=1;j<c1;++j)
        printf(" ");
    printf("%d",n);
    for(j=1;j<c2;++j)
        printf(" ");    
    printf("*\n");    
    
    
    for(i=1;i<r2;++i){
        printf("*");
        for(j=2;j<column_count;++j)
            printf(" ");
        printf("*\n");    
    }
    
    for(i=0;i<column_count;++i)
        printf("*");
    printf("\n");
}     
int basamak(int n)
{
    int count=0;
        
    while(n){
        
        n/=10;
        
        count++;    
    }
    
    return count;   
}
/*############################################################################*/
/*              End of HW03_Onur_Sezer_121044074                              */
/*############################################################################*/
